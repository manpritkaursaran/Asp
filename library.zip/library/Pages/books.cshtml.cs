using System.Collections.Generic;
using library.Models; 
using library.Services; 
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;

namespace library.Pages
{
    public class booksModel : PageModel
    {
        private readonly BookService _bookService;

        public booksModel(BookService bookService)
        {
            _bookService = bookService;
        }

        public List<books> books { get; private set; }

        
    }
}
