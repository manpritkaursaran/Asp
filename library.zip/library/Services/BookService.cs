﻿namespace library.Services
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using library.Models;
    using Microsoft.AspNetCore.Hosting;
    using Newtonsoft.Json;

    public class BookService
    {
        private readonly IWebHostEnvironment _webHostEnvironment;

        public BookService(IWebHostEnvironment webHostEnvironment)
        {
            _webHostEnvironment = webHostEnvironment;
        }

        public IWebHostEnvironment WebHostEnvironment => _webHostEnvironment;

        private string JsonFileName => Path.Combine(WebHostEnvironment.WebRootPath, "data", "books.json");

        public IEnumerable<books> GetBooks()
        {
            using var jsonFileReader = System.IO.File.OpenText(JsonFileName);
            return ReadFile(jsonFileReader);
        }

        private books[] ReadFile(StreamReader jsonFileReader)
        {
            return ReadFile(jsonFileReader, JsonConvert);
        }

        private books[] ReadFile(StreamReader jsonFileReader, JsonConvert jsonConvert)
        {
            var serializerSettings = new JsonSerializerSettings
            {
                ContractResolver = new Newtonsoft.Json.Serialization.DefaultContractResolver
                {
                    NamingStrategy = new Newtonsoft.Json.Serialization.CamelCaseNamingStrategy()
                }
            };

            return jsonConvert.DeserializeObject<books[]>(jsonFileReader.ReadToEnd(), serializerSettings);
        }
    }
}

