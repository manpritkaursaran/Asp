﻿namespace library.Models
{

    public class books
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public string Genre { get; set; }
        public string ContentType { get; set; }
        public string PublishDate { get; set; }
        public string ImageLink { get; set; }
    }
}

